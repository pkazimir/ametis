<?php
class Files_model extends Model {

    function getCategories() {
        
        $laCategories = $this->db->query('SELECT * FROM files_categories');
        
        return $laCategories->result_array();
    }
    
    function getFiles() {
        
        $laFiles = $this->db->query('SELECT * FROM files');
        
        return $laFiles->result_array();
    }
}  
?>
