<table cellpadding="5" cellspacing="0" border="0" width="900">
<tr>
    <td width="185" valign="top">
        
        <!-- SEARCH -->
        <table cellpadding="0" cellspacing="0" border="0">
        <tr>
            <td width="6" height="29" background="images/files/header_border_left.JPG"></td>
            <td width="170" background="images/files/header_border_bg.JPG" class="header_text">&nbsp;&nbsp;&nbsp;Search</td>
            <td width="6" background="images/files/header_border_right.JPG"></td>
        </tr>
        </table>

        <!-- SEARCH form -->
        <table cellpadding="3" cellspacing="0" border="0">
        <tr>
            <td width="174" class="search_form" align="center">
            <form action="index.php" enctype="multipart/form-data" method="get">
            <input type="text" size="15" class="search_input" name="keyword"><input type="submit" value="OK" class="search_button">
            <input type="hidden" name="siteID" value="">
            </form>
            </td>
        </tr>
        </table>
    </td>
    
    <!-- RIGHT SIDE -->
    
    <td valign="top">
        
        <!-- ADD FILE -->
        <table cellpadding="0" cellspacing="0" border="0" align="center">
        <tr>
            <td class="add_form main_font" width="431">

                <?php echo form_open_multipart('upload/do_upload');?>
            
                <b>Upload file:</b>
                
                <input type="file" name="userfile" size="30" class="search_input" />

                <input type="submit" value="upload" class="search_button" />
                </form>
            </td>
        </tr>
        </table>
        
        <br>
        
        <form action="index.php" method="get" enctype="multipart/form-data" name="main_form">
        <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr>
            <!-- checkbox -->
            <td width="206"><!-- FILENAME -->
                <table cellpadding="0" cellspacing="0" border="0">
                <tr>
                    <td width="6" height="29" background="images/files/header_border_left.JPG"></td>
                    <td width="200" background="images/files/header_border_bg.JPG" class="header_text">&nbsp;&nbsp;&nbsp;Filename</td>
                    
                </tr>
                </table>
            </td>
            <td><!-- INFO -->
                <table cellpadding="0" cellspacing="0" border="0">
                <tr>            
                    <td width="100%" background="images/files/header_border_bg.JPG" class="header_text">&nbsp;&nbsp;&nbsp;Info</td>
                    <td width="6" height="29" background="images/files/header_border_bg.JPG"></td>
                </tr>
                </table>
            </td>
            <td width="106"><!-- DATE -->
                <table cellpadding="0" cellspacing="0" border="0">
                <tr>    
                    <td width="100" background="images/files/header_border_bg.JPG" class="header_text" align="center">Date</td>
                    <td width="6" height="29" background="images/files/header_border_right.JPG"></td>
                </tr>
                </table>
            </td>
            <!-- EDIT button -->
            <td width="25"></td>
            <td width="25"></td>
        </tr>
        <?php foreach($laFiles as $laFile): ?>
        <tr>
            <td class="body_text"><div class="filename"><?php echo $laFile['name'] ?></div></td>
            <td class="body_text"><?php echo $laFile['info'] ?></td>
            <td class="body_text" align="center"><?php echo date("d / m / Y", strtotime($laFile['date'])) ?></td>
            <td align="center"><a href="<?php echo site_url(array('ametis', 'editFile', $laFile['id_file'])); ?>" class="edit_delete_button"><img src="images/breakfast/b_edit.png" border="0"></a></td>
            <td align="center"><a href="<?php echo site_url(array('ametis', 'deleteFile', $laFile['id_file'])); ?>" class="edit_delete_button"><img src="images/breakfast/b_drop.png" border="0"></a></td>
        </tr>
        <?php endforeach; ?>
        </table>
        </form>
    </td>
</tr>
</table>