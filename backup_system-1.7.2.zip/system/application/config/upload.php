<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config['upload_img'] = '';
$config['upload_doc'] = '';
$config['upload_video'] = '';
$config['upload_audio'] = '';
$config['upload_all'] = $config['upload_audio'].'|'.$config['upload_video'].'|'.$config['upload_doc'].'|'.$config['upload_img'];
?>
