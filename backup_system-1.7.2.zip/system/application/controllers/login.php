<?php
class Login extends Controller {
    
    function index() {
        
        $this->load->view('login/login');
    }
}
?>
