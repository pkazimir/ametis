<?php
class Upload extends Controller {
    
    function Upload()
    {
        parent::Controller();
        $this->load->helper(array('form', 'url'));
    }
    
    function index()
    {    
        $this->load->view('ametis/showFiles', array('error' => ' ' ));
    }

    function do_upload()
    {
        $config['upload_path'] = 'uploads/';
        $config['allowed_types'] = $this->config->item('upload_all');
        
        $this->load->library('upload', $config);
    
        if ( ! $this->upload->do_upload())
        {
            $error = array('error' => $this->upload->display_errors());
            echo CI_VERSION;
            var_dump($error);
        }    
        else
        {
            $data = array('upload_data' => $this->upload->data());
            
            echo "good!";
        }
    }    
}
?>
