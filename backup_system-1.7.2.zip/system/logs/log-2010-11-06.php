<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-11-06 14:46:56 --> 404 Page Not Found --> blog/shoes
ERROR - 2010-11-06 14:47:08 --> 404 Page Not Found --> blog/shoes
ERROR - 2010-11-06 15:57:20 --> Severity: Notice  --> Undefined variable: imgpath C:\wamp\www\ametis_new\system\libraries\Loader.php(673) : eval()'d code 3
ERROR - 2010-11-06 15:57:20 --> Severity: Notice  --> Use of undefined constant User - assumed 'User' C:\wamp\www\ametis_new\system\libraries\Loader.php(673) : eval()'d code 4
ERROR - 2010-11-06 15:57:20 --> Severity: Notice  --> Undefined index:  User C:\wamp\www\ametis_new\system\libraries\Loader.php(673) : eval()'d code 4
ERROR - 2010-11-06 15:57:20 --> Severity: Notice  --> Undefined variable: imgpath C:\wamp\www\ametis_new\system\libraries\Loader.php(673) : eval()'d code 5
ERROR - 2010-11-06 15:57:20 --> Severity: Notice  --> Undefined variable: imgpath C:\wamp\www\ametis_new\system\libraries\Loader.php(673) : eval()'d code 5
ERROR - 2010-11-06 15:57:20 --> Severity: Notice  --> Undefined variable: imgpath C:\wamp\www\ametis_new\system\libraries\Loader.php(673) : eval()'d code 6
ERROR - 2010-11-06 15:57:20 --> Severity: Notice  --> Undefined variable: TBL_KERNEL_MENU C:\wamp\www\ametis_new\system\libraries\Loader.php(673) : eval()'d code 22
ERROR - 2010-11-06 15:57:21 --> Severity: Warning  --> mysql_query() [<a href='function.mysql-query'>function.mysql-query</a>]: Access denied for user 'ODBC'@'localhost' (using password: NO) C:\wamp\www\ametis_new\system\libraries\Loader.php(673) : eval()'d code 22
ERROR - 2010-11-06 15:57:21 --> Severity: Warning  --> mysql_query() [<a href='function.mysql-query'>function.mysql-query</a>]: A link to the server could not be established C:\wamp\www\ametis_new\system\libraries\Loader.php(673) : eval()'d code 22
ERROR - 2010-11-06 15:57:21 --> Severity: Warning  --> mysql_num_rows(): supplied argument is not a valid MySQL result resource C:\wamp\www\ametis_new\system\libraries\Loader.php(673) : eval()'d code 23
ERROR - 2010-11-06 15:57:21 --> Severity: Warning  --> mysql_fetch_array(): supplied argument is not a valid MySQL result resource C:\wamp\www\ametis_new\system\libraries\Loader.php(673) : eval()'d code 25
ERROR - 2010-11-06 15:57:21 --> Severity: Notice  --> Undefined variable: imgpath C:\wamp\www\ametis_new\system\libraries\Loader.php(673) : eval()'d code 53
ERROR - 2010-11-06 15:57:21 --> Severity: Notice  --> Undefined variable: imgpath C:\wamp\www\ametis_new\system\libraries\Loader.php(673) : eval()'d code 55
ERROR - 2010-11-06 15:57:21 --> Severity: Notice  --> Undefined variable: imgpath C:\wamp\www\ametis_new\system\libraries\Loader.php(673) : eval()'d code 61
